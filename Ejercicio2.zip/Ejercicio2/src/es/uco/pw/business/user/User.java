package es.uco.pw.business.user;

public class User {
	String email = "";
	String password="";
	String name = "";
	int edad = -1;
	
	
	public User (String email,String password, String name, int edad) {
		this.email = email;
		this.password = password;
		this.name = name;
		this.edad = edad;
	}
	
	public User (String email,String password, String name, String edad) {
		this.email = email;
		this.password = password;
		this.name = name;
		this.edad = Integer.parseInt(edad);
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String toString() {
		return "Email: " + this.getEmail() + "; name: " + this.getName() + "; edad: " + Integer.toString(this.getEdad());
	}
	
}
