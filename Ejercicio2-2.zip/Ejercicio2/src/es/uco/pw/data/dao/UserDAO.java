// En la pr�ctica, la clase deber�a ir en <es.uco.pw.data.dao>
package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import es.uco.pw.business.user.User;

// Ser�a recomendable tener una clase DAO que guardara los m�todos comunes (p.ej. getConnection()) y 
// de la que heredase esta clase y el resto de DAOs
public class UserDAO {
	
	private static String servidor, puerto, user, pass;
	private static String Usave, Uupdate, Uselect;
	
  // M�todo que establece la conexi�n con la base de datos
  // NOTA: Los m�todos est�ticos no son obligatorios (ni siquiera los m�s apropiados):
  // Se ha escrito de esta manera �nicamente para facilitar la ejecuci�n
  public static Connection getConnection(){
	// En primer lugar, obtenemos una instancia del driver de MySQL
	Connection con=null;
	try {
	  Class.forName("com.mysql.jdbc.Driver");

	  Properties configBD = new Properties();
	  try {
		  	FileInputStream configBDruta = new FileInputStream("C:\\Users\\juan1\\eclipse-workspace\\Ejercicio2\\WebContent\\WEB-INF\\config.properties.txt");
			configBD.load(configBDruta);
			servidor = configBD.getProperty("conf.servidor");
			puerto = configBD.getProperty("conf.puerto");
			user = configBD.getProperty("conf.usuario");
			pass = configBD.getProperty("conf.pass");
		} catch(IOException e) {
			System.out.println(e.toString());
		}
	  
	  con= DriverManager.getConnection("jdbc:mysql://"+ servidor + ":" + puerto + "/" + user,user,pass);
	  
	  Properties sql = new Properties();
		
		try {
			String ruta = "C:\\Users\\juan1\\eclipse-workspace\\Ejercicio2\\WebContent\\WEB-INF\\sql.properties.txt";
			FileInputStream configSQLruta = new FileInputStream(ruta);
			
			sql.load(configSQLruta);
			Usave = sql.getProperty("sql.Usave");
			Uupdate = sql.getProperty("sql.Uupdate");
			Uselect = sql.getProperty("sql.Uselect");
		} catch(IOException e) {
			System.out.println(e.toString());
		}
		
		
		
	// Importante capturar 
	} catch(Exception e) {
	  System.out.println(e);
	}
	return con;
  }
  
  
  
  // M�todo para insertar una fila
  // En ning�n caso es recomendable el paso por par�metro de los valores individuales
  // Se recomienda utilizar el UserBean o una clase envoltorio User que tenga estas propiedades
  public int save(User usuario){
	int status=0;
	try{
		Connection con=getConnection();
		// PreparedStament ser� m�s r�pido (si es uso recurrente) y permite invocaci�n a par�metros
		// Lo habitual es que las consultas y sentencias SQL est�n en un fichero de propiedades aparte, no en c�digo
		PreparedStatement ps=con.prepareStatement(Usave);
		// El orden de los par�metros debe coincidir con las '?' del c�digo SQL
		ps.setString(1,usuario.getEmail());
		ps.setString(2,usuario.getPassword());
		ps.setString(3,usuario.getName());
		ps.setInt(4,usuario.getEdad());
		
		status = ps.executeUpdate();
	// Importante capturar las excepciones. Si nuestra aplicaciones tiene m�s opciones de fallo,
	// podemos capturar directamente SQLException
	}catch(Exception e){System.out.println(e);}
	// El invocante siempre deber�a tener informaci�n del resultado de la sentencia SQL
	return status;
}
  
// M�todo para actualizar un usuario
public static int update(User usuario){
	int status=0;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement(Uupdate);
		ps.setString(1,usuario.getPassword());
		ps.setString(2,usuario.getName());
		ps.setInt(3,usuario.getEdad());
		ps.setString(4,usuario.getEmail());
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}

// Para la consulta, se ha tomado una estructura Hash (columna-tabla, valor)
public User queryByEmail (String email) {
	Statement stmt = null; 
	User aux = null;
	try {
		Connection con=getConnection();
		// En consultas, se hace uso de un Statement 
		stmt = con.createStatement();
		
	    ResultSet rs = stmt.executeQuery(Uselect + email + "'");
	    while (rs.next()) {
	    	String password = rs.getString("Password");
	        String name = rs.getString("Name");
	        int edad = rs.getInt("Edad");
	        aux = new User(email,password,name,edad);
	        
	    }
	    // Se debe tener precauci�n con cerrar las conexiones, uso de auto-commit, etc.
	    if (stmt != null) 
	    	stmt.close(); 
	} catch (Exception e) {
		System.out.println(e);
	} 
	return aux;
} 


}