// En la pr�ctica, la clase deber�a ir en <es.uco.pw.data.dao>
package ejercicio1;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

// Ser�a recomendable tener una clase DAO que guardara los m�todos comunes (p.ej. getConnection()) y 
// de la que heredase esta clase y el resto de DAOs
public class AnuncioDAO {
	
	
	private static String AsaveGeneral, AsaveTematico, AsaveIndiv, AsaveFlash;
	private static String AupdateGeneral, AupdateTematico, AupdateIndiv, AupdateFlash;
	private static String Aselect, Adelete, Acount;
	
	private static void leerSQLProperties()
	{
		Properties sql = new Properties();
		
		try {
			FileInputStream is = new FileInputStream("C:\\Users\\juan1\\eclipse-workspace\\practica2\\src\\ejercicio1\\sql.properties.txt");
			sql.load(is);
		} catch(IOException e) {
			System.out.println(e.toString());
		}
		AsaveGeneral = sql.getProperty("sql.AsaveGeneral");
		AsaveTematico = sql.getProperty("sql.AsaveTematico");
		AsaveIndiv = sql.getProperty("sql.AsaveIndiv");
		AsaveFlash = sql.getProperty("sql.AsaveFlash");
		AupdateGeneral = sql.getProperty("sql.AupdateGeneral");
		AupdateTematico = sql.getProperty("sql.AupdateTematico");
		AupdateIndiv = sql.getProperty("sql.AupdateIndiv");
		AupdateFlash = sql.getProperty("sql.AupdateFlash");
		Aselect = sql.getProperty("sql.Aselect");
		Adelete = sql.getProperty("sql.Adelete");
		Acount = sql.getProperty("sql.Acount");
	}
	
  // M�todo que establece la conexi�n con la base de datos
  // NOTA: Los m�todos est�ticos no son obligatorios (ni siquiera los m�s apropiados):
  // Se ha escrito de esta manera �nicamente para facilitar la ejecuci�n
  public static Connection getConnection(){
	// En primer lugar, obtenemos una instancia del driver de MySQL
	Connection con=null;
	try {
	  Class.forName("com.mysql.jdbc.Driver");
	  // Introducir correctamente el nombre y datos de conexi�n - Idealmente, estos datos se 
	  // indican en un fichero de propiedades
	  con= DriverManager.getConnection("jdbc:mysql://oraclepr.uco.es:3306/"+ Main.usuario,Main.usuario,Main.pass);
	  
	  leerSQLProperties();
	// Importante capturar 
	} catch(Exception e) {
	  System.out.println(e);
	}
	return con;
  }
  
  // M�todo para insertar una fila
  // En ning�n caso es recomendable el paso por par�metro de los valores individuales
  // Se recomienda utilizar el UserBean o una clase envoltorio User que tenga estas propiedades
  public static int save(Anuncio anuncio){
	int status=0;
	try{
		Connection con=getConnection();
		PreparedStatement ps = null;
		if(anuncio.getTipo().equals("general"))
		{
			ps=con.prepareStatement(AsaveGeneral);
			ps.setInt(1,anuncio.getId());
			ps.setString(2,anuncio.getTitulo());
			ps.setString(3,anuncio.getPropietario());
			ps.setString(4,anuncio.getCuerpo());
			ps.setString(5,anuncio.getTipo());
	    	ps.setString(6,anuncio.getFase());
		}
		else if(anuncio.getTipo().equals("tematico"))
		{
			ps=con.prepareStatement(AsaveTematico);
			ps.setInt(1,anuncio.getId());
			ps.setString(2,anuncio.getTitulo());
			ps.setString(3,anuncio.getPropietario());
			ps.setString(4,anuncio.getCuerpo());
			ps.setString(5,anuncio.getTipo());
	    	ps.setString(6,anuncio.getFase());
	    	ps.setString(7,anuncio.getTag());
		}
		else if(anuncio.getTipo().equals("individualizado"))
		{
			ps=con.prepareStatement(AsaveIndiv);
			ps.setInt(1,anuncio.getId());
			ps.setString(2,anuncio.getTitulo());
			ps.setString(3,anuncio.getPropietario());
			ps.setString(4,anuncio.getDestinatario());
			ps.setString(5,anuncio.getCuerpo());
			ps.setString(6,anuncio.getTipo());
	    	ps.setString(7,anuncio.getFase());
		}
		else if(anuncio.getTipo().equals("flash"))
		{
			ps=con.prepareStatement(AsaveFlash);
			ps.setInt(1,anuncio.getId());
			ps.setString(2,anuncio.getTitulo());
			ps.setString(3,anuncio.getPropietario());
			ps.setString(4,anuncio.getCuerpo());
			ps.setString(5,anuncio.getTipo());
	    	ps.setString(6,anuncio.getFase());
	    	ps.setString(7,anuncio.getFechaComienzo());
	    	ps.setString(8,anuncio.getFechaFin());
		}
		
		status = ps.executeUpdate();
	// Importante capturar las excepciones. Si nuestra aplicaciones tiene m�s opciones de fallo,
	// podemos capturar directamente SQLException
	}catch(Exception e){System.out.println(e);}
	// El invocante siempre deber�a tener informaci�n del resultado de la sentencia SQL
	return status;
}
  
// M�todo para actualizar un usuario
public static int update(Anuncio anuncio){
	int status=0;
	PreparedStatement ps = null;
	try{
		Connection con=getConnection();
		
		if(anuncio.getTipo().equals("general"))
		{
			ps=con.prepareStatement(AupdateGeneral);
			
			ps.setString(1,anuncio.getTitulo());
			ps.setString(2,anuncio.getPropietario());
			ps.setString(3,anuncio.getCuerpo());
			ps.setString(4,anuncio.getTipo());
	    	ps.setString(5,anuncio.getFase());
	    	ps.setInt(6,anuncio.getId());
		}
		else if(anuncio.getTipo().equals("tematico"))
		{
			ps=con.prepareStatement(AupdateTematico);
			
			ps.setString(1,anuncio.getTitulo());
			ps.setString(2,anuncio.getPropietario());
			ps.setString(3,anuncio.getCuerpo());
			ps.setString(4,anuncio.getTipo());
	    	ps.setString(5,anuncio.getFase());
	    	ps.setString(6,anuncio.getTag());
	    	ps.setInt(7,anuncio.getId());
		}
		else if(anuncio.getTipo().equals("individualizado"))
		{
			ps=con.prepareStatement(AupdateIndiv);
			
			ps.setString(1,anuncio.getTitulo());
			ps.setString(2,anuncio.getPropietario());
			ps.setString(3,anuncio.getDestinatario());
			ps.setString(4,anuncio.getCuerpo());
			ps.setString(5,anuncio.getTipo());
	    	ps.setString(6,anuncio.getFase());
	    	ps.setInt(7,anuncio.getId());
		}
		else if(anuncio.getTipo().equals("flash"))
		{
			ps=con.prepareStatement(AupdateFlash);
			
			ps.setString(1,anuncio.getTitulo());
			ps.setString(2,anuncio.getPropietario());
			ps.setString(3,anuncio.getCuerpo());
			ps.setString(4,anuncio.getTipo());
	    	ps.setString(5,anuncio.getFase());
	    	ps.setString(6,anuncio.getFechaComienzo());
	    	ps.setString(7,anuncio.getFechaFin());
	    	ps.setInt(8,anuncio.getId());
		}
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}

// Para la consulta, se ha tomado una estructura Hash (columna-tabla, valor)
public static Anuncio queryById (int id) {
	Statement stmt = null; 
	Anuncio aux = null;
	try {
		Connection con=getConnection();
		// En consultas, se hace uso de un Statement 
		stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(Aselect+id+"'");
	    while (rs.next()) {
	    	String titulo = rs.getString("Titulo");
	        String propietario = rs.getString("Propietario");
	        String destinatario = rs.getString("Destinatarios");
         	String cuerpo = rs.getString("Cuerpo");
         	String tipo = rs.getString("Tipo");
         	String fase = rs.getString("Fase");
         	String tag = rs.getString("Tag");
         	String fcom = rs.getString("FComienzo");
         	String ffin = rs.getString("FFin");

	        aux = new Anuncio();
	        aux.setId(id);
	        aux.setTitulo(titulo);
	        aux.setPropietario(propietario);
	        aux.setDestinatario(destinatario);
	        aux.setCuerpo(cuerpo);
	        aux.setFase(fase);
	        aux.setTipo(tipo);
	        aux.setTag(tag);
	        aux.setFechaComienzo(fcom);
	        aux.setFechaFin(ffin);
	    }
	    // Se debe tener precauci�n con cerrar las conexiones, uso de auto-commit, etc.
	    if (stmt != null) 
	    	stmt.close(); 
	} catch (Exception e) {
		System.out.println(e);
	} 
	return aux;
} 

public static int count() {
	
	int cont = 0;
	Statement stmt = null;
	try{
		Connection con=getConnection();
		stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(Acount);
		if(rs.next()) {
		cont=rs.getInt(1);
		}
		if (stmt != null) 
	    	stmt.close();
	}catch(Exception e){System.out.println(e);}

	return cont;
}

public static int delete(int id){
	int status=0;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement(Adelete);
		ps.setInt(1,id);
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}

	return status;
}
}